$ErrorActionPreference = "Stop"

$sourceRoot = Join-Path $PSScriptRoot ".codex"
$targetRoot = Join-Path $HOME ".codex"

if (-not (Test-Path $sourceRoot)) {
    throw "Source .codex folder not found next to restore-codex-skills.ps1"
}

$targets = @(
    @{ Source = Join-Path $sourceRoot "skills"; Target = Join-Path $targetRoot "skills" },
    @{ Source = Join-Path $sourceRoot "superpowers"; Target = Join-Path $targetRoot "superpowers" }
)

foreach ($item in $targets) {
    if (-not (Test-Path $item.Source)) {
        continue
    }

    New-Item -ItemType Directory -Force -Path $item.Target | Out-Null

    Get-ChildItem $item.Source -Force | ForEach-Object {
        $destination = Join-Path $item.Target $_.Name
        Copy-Item -Recurse -Force $_.FullName $destination
    }
}

Write-Host "Skills restored into $targetRoot"
Write-Host "Restart Codex to load the restored skills."
