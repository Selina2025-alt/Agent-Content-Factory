# Codex Skills Export

Export date: 2026-04-07

This backup contains the non-system skills from this machine, organized in a `.codex`-compatible layout so they can be restored on another computer.

Included custom skills:

- `docx`
- `frontend-design`
- `pdf`
- `pptx`
- `xlsx`

Included superpowers skills:

- `brainstorming`
- `dispatching-parallel-agents`
- `executing-plans`
- `finishing-a-development-branch`
- `receiving-code-review`
- `requesting-code-review`
- `subagent-driven-development`
- `systematic-debugging`
- `test-driven-development`
- `using-git-worktrees`
- `using-superpowers`
- `verification-before-completion`
- `writing-plans`
- `writing-skills`

Not included:

- Built-in system skills from `.codex/skills/.system`
- Auth/session files
- Machine-specific Codex state

## Restore On Another Computer

1. Close Codex completely.
2. Copy this whole folder to the other computer.
3. Open PowerShell in this folder.
4. Run:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\restore-codex-skills.ps1
```

5. Start Codex again.

## Manual Restore

If you do not want to run the script, copy these folders into your home directory so they merge into `~/.codex`:

- `.codex\skills`
- `.codex\superpowers`

## Notes

- This restore does not delete anything on the target machine.
- If the target already has a skill with the same folder name, the exported files will overwrite matching files in that skill folder.
